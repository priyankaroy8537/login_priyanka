package com.nau.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.nau.model.LoginModel;
import com.nau.util.DBConnection;

public class LoginDao {

	private Connection connection = DBConnection.getConnection();

	public LoginModel getUserById(String id) {
		String sql = "select * from userlogin where userid=?";
		LoginModel loginModel = null;
		try {
			PreparedStatement ps = connection.prepareStatement(sql);
			ps.setString(1,id);
			ResultSet rs= ps.executeQuery();
			if(rs.next()) {
				loginModel = new LoginModel(rs.getString(1),rs.getString(2));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return loginModel;
	}

}
