package com.nau.service;

import com.nau.dao.LoginDao;
import com.nau.model.LoginModel;

public class LoginService {
	
	
	private LoginDao loginDao = new LoginDao();
	
	public Integer validateUserLogin(String userId,String password) {
		
		Integer message = 0;
		
		LoginModel loginModel = loginDao.getUserById(userId);
		if(loginModel!=null) {
			if(loginModel.getPassword().equals(password)) {
				message = 1;
			}else {
				message = 2;
			}
		}else {
			message = 0;
		}
		
		
		return message;
		
	}
	
	

}
