package com.nau.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/loginhome")
public class LoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public LoginController() {
		System.out.println("Login Controller Obejct careated");
	}

	@Override
	public void init() throws ServletException {
		System.out.println("init method");
	}

	@Override
	public void destroy() {
		System.out.println("DEstroy");
	}

//	@Override
//	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
//		System.out.println(req.getMethod());
//		
//	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		System.out.println("Get Method");
		RequestDispatcher rd = req.getRequestDispatcher("/WEB-INF/safeviews/loginhome.html");
		rd.forward(req, resp);
	}
//
//	@Override
//	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
//		PrintWriter out = resp.getWriter();
//		out.print("Welcome Buddy POST method ");
//		String uname = req.getParameter("uname");
//		out.print("<h1>Welcome Buddy POST method " + uname + "</h1>");
//	}

}
