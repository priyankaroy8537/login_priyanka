package com.nau.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.nau.service.LoginService;

@WebServlet("/validateuser")
public class ValidateUserController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Override
	protected void doPost(HttpServletRequest req, 
			HttpServletResponse resp) throws ServletException, IOException {
		PrintWriter out = resp.getWriter();
		resp.setContentType("text/html");
		String userid = req.getParameter("userid");
		String password = req.getParameter("password");
		
		
		LoginService loginService = new LoginService();
		Integer result = loginService.validateUserLogin(userid, password);
		// service class  // dao class //  
			
		RequestDispatcher welcome = req.getRequestDispatcher("/WEB-INF/safeviews/welcome.jsp");
		RequestDispatcher loginHome = req.getRequestDispatcher("/WEB-INF/safeviews/loginhome.html");
		String message = "Invalid User : ";
		if (userid.equals(password)) {
			req.setAttribute("fname", "Priyanka");
			req.setAttribute("lname", "Roy");
			welcome.forward(req, resp);
		} else {
			out.print(message);
			loginHome.include(req, resp);
		}
		System.out.println(userid + " " + password);
	}
}
